
# SchoolSaaS Self-Hosted Edition

## Installation

1.  Ensure Node.js (v16+) and PostgreSQL are installed.
2.  Run `./setup.sh` to install dependencies.
3.  Configure your database connection in `backend/.env`.
    *   Ensure `LICENSE_KEY` is set to the key provided.
4.  Start the server with `cd backend && npm start`.

## License

This copy is licensed to the specific entity named in the license key.
Redistribution is strictly prohibited.
Code is protected and obfuscated.
    