const express = require('express');
const router = express.Router();
const { School, Subscription, Plan, Student, Invoice, SchoolSettings } = require('../models');
const { sequelize } = require('../models');
const { verifyToken, requireRole, requireSameSchoolParam, requirePermission, isSuperAdminUser } = require('../middleware/auth');
const { requireModule, moduleMap } = require('../middleware/modules');
const { derivePermissionsForUser } = require('../utils/permissionMatrix');

// Public endpoint alias to list schools without auth
router.get('/public', async (req, res) => {
  try {
    const Op = require('sequelize').Op;
    const schools = await School.findAll({
      include: [{ model: Subscription, include: { model: Plan } }],
      order: [['name', 'ASC']],
    });
    const ids = schools.map(s => s.id);
    const settingsRows = await SchoolSettings.findAll({ where: { schoolId: { [Op.in]: ids } } });
    const byId = new Map(settingsRows.map(r => [Number(r.schoolId), r]));
    const visible = schools.filter(s => {
      const st = byId.get(Number(s.id));
      return !st || String(st.operationalStatus).toUpperCase() !== 'DELETED';
    });
    const formattedSchools = visible.map(school => {
      const s = school.toJSON();
      return {
        id: s.id,
        name: s.name,
        plan: 'N/A',
        status: 'N/A',
        students: 0,
        teachers: 0,
        balance: 0,
        joinDate: ''
      };
    });
    res.json(formattedSchools);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// @route   GET api/schools
// @desc    Get all schools with their subscription details
// @access  Private (SuperAdmin) / Public for login screen
router.get('/', async (req, res) => {
  try {
    if (req.user && !isSuperAdminUser(req.user)) {
      return res.status(403).json({ msg: 'Access denied' });
    }
    const Op = require('sequelize').Op;
    const schools = await School.findAll({
      include: [{ model: Subscription, include: { model: Plan } }],
      order: [['name', 'ASC']],
    });
    const ids = schools.map(s => s.id);
    const settingsRows = await SchoolSettings.findAll({ where: { schoolId: { [Op.in]: ids } } });
    const byId = new Map(settingsRows.map(r => [Number(r.schoolId), r]));
    const visible = schools.filter(s => {
      const st = byId.get(Number(s.id));
      return !st || String(st.operationalStatus).toUpperCase() !== 'DELETED';
    });

    const formattedSchools = visible.map(school => {
      const schoolJSON = school.toJSON();
      if (!req.user) {
        return {
          id: schoolJSON.id,
          name: schoolJSON.name,
          plan: 'N/A',
          status: 'N/A',
          students: 0,
          teachers: 0,
          balance: 0,
          joinDate: ''
        };
      }
      return {
        id: schoolJSON.id,
        name: schoolJSON.name,
        plan: schoolJSON.Subscription?.Plan?.name || 'N/A',
        status: schoolJSON.Subscription?.status || 'N/A',
        students: schoolJSON.studentCount,
        teachers: schoolJSON.teacherCount,
        balance: parseFloat(schoolJSON.balance),
        joinDate: schoolJSON.createdAt.toISOString().split('T')[0],
      };
    });

    res.json(formattedSchools);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// @route   GET api/schools/:id
// @desc    Get a single school by id with its subscription details
// @access  Private (SchoolAdmin) / Public where appropriate
router.get('/:id', verifyToken, requireSameSchoolParam('id'), async (req, res) => {
  try {
    const school = await School.findByPk(req.params.id, {
      include: {
        model: Subscription,
        include: { model: Plan },
      },
    });
    if (!school) return res.status(404).json({ msg: 'School not found' });
    try {
      const settings = await SchoolSettings.findOne({ where: { schoolId: Number(req.params.id) } });
      if (settings && String(settings.operationalStatus).toUpperCase() === 'DELETED') {
        return res.status(404).json({ msg: 'School not found' });
      }
    } catch {}
    const s = school.toJSON();
    return res.json({
      id: s.id,
      name: s.name,
      plan: s.Subscription?.Plan?.name || 'N/A',
      status: s.Subscription?.status || 'N/A',
      students: s.studentCount,
      teachers: s.teacherCount,
      joinDate: new Date(s.createdAt).toISOString().split('T')[0],
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// @route   POST api/schools
// @desc    Add a new school with 30-day trial and initial admin
// @access  Private (SuperAdmin)
router.post('/', verifyToken, requireRole('SUPER_ADMIN'), async (req, res) => {
  try {
    const payload = req.body || {};
    const schoolData = payload.school || {};
    const adminData = payload.admin || {};
    const subData = payload.subscription || {};
    if (!schoolData.name || !schoolData.contactEmail) return res.status(400).json({ msg: 'Invalid school data' });
    if (!adminData.name || !adminData.email || !adminData.password) return res.status(400).json({ msg: 'Invalid admin data' });
    const plan = await Plan.findByPk(Number(subData.planId || 1));
    if (!plan) return res.status(400).json({ msg: 'Invalid planId' });

    const existingSchool = await School.findOne({ where: { name: schoolData.name } });
    if (existingSchool) return res.status(400).json({ msg: 'School already exists' });

    const school = await School.create({ name: schoolData.name, contactEmail: schoolData.contactEmail, studentCount: 0, teacherCount: 0, balance: 0 });

    // 30-day trial subscription
    const start = new Date();
    const end = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
    await Subscription.create({ schoolId: school.id, planId: plan.id, status: 'TRIAL', startDate: start, endDate: end, renewalDate: end });

    // Default settings
    const academicStart = new Date(start.getFullYear(), 8, 1); // Sep 1
    const academicEnd = new Date(start.getFullYear() + 1, 5, 20); // Jun 20 next year
    await SchoolSettings.create({ schoolId: school.id, schoolName: school.name, schoolAddress: schoolData.address || '', academicYearStart: academicStart, academicYearEnd: academicEnd, notifications: { email: true, sms: false, push: true }, availableStages: ["رياض أطفال","ابتدائي","إعدادي","ثانوي"], operationalStatus: 'ACTIVE' });

    // Create initial admin user
    const bcrypt = require('bcryptjs');
    const username = String(adminData.email).split('@')[0];
    const existsUser = await require('../models').User.findOne({ where: { [require('sequelize').Op.or]: [{ email: adminData.email }, { username }] } });
    if (existsUser) return res.status(400).json({ msg: 'Admin email already exists' });
    const hash = await bcrypt.hash(String(adminData.password), 10);
    const permissions = derivePermissionsForUser({ role: 'SchoolAdmin', schoolRole: 'مدير' });
    const admin = await require('../models').User.create({ name: adminData.name, email: adminData.email, username, password: hash, role: 'SchoolAdmin', schoolId: school.id, schoolRole: 'مدير', isActive: true, permissions, passwordMustChange: true, tokenVersion: 0 });

    const response = { id: school.id, name: school.name, plan: plan.name, status: 'TRIAL', students: school.studentCount, teachers: school.teacherCount, balance: parseFloat(school.balance), joinDate: school.createdAt.toISOString().split('T')[0] };
    res.status(201).json(response);
  } catch (err) { console.error(err.message); res.status(500).send('Server Error'); }
});

// Get subscription details for a school
router.get('/:id/subscription', verifyToken, requireRole('SUPER_ADMIN'), async (req, res) => {
  try {
    const sub = await Subscription.findOne({ where: { schoolId: Number(req.params.id) }, include: [{ model: Plan }] });
    if (!sub) return res.status(404).json({ msg: 'Subscription not found' });
    const p = sub.Plan;
    const price = p ? parseFloat(p.price) : 0;
    return res.json({
      id: String(sub.id),
      schoolId: Number(sub.schoolId),
      schoolName: '',
      plan: p?.name || 'N/A',
      status: sub.status || 'N/A',
      startDate: sub.startDate ? new Date(sub.startDate).toISOString().split('T')[0] : '',
      renewalDate: sub.renewalDate ? new Date(sub.renewalDate).toISOString().split('T')[0] : '',
      amount: price,
      trialEndDate: sub.endDate ? new Date(sub.endDate).toISOString().split('T')[0] : undefined,
    });
  } catch (e) { console.error(e); res.status(500).json({ msg: 'Server Error' }); }
});

// Billing summary for a school
router.get('/:id/billing/summary', verifyToken, requireRole('SUPER_ADMIN'), async (req, res) => {
  try {
    const { Invoice, Student } = require('../models');
    try { await Invoice.sync({ alter: true }); } catch (e) { console.error('Sync Invoice Error:', e); }

    const sid = Number(req.params.id);
    const rows = await Invoice.findAll({ include: [{ model: Student, where: { schoolId: sid }, attributes: [] }] });
    let paid = 0, unpaid = 0, overdue = 0, total = 0, outstanding = 0;
    rows.forEach(r => {
      const amt = parseFloat(r.amount || 0);
      total += amt;
      if (String(r.status).toUpperCase() === 'PAID') paid++;
      else if (String(r.status).toUpperCase() === 'OVERDUE') { overdue++; outstanding += amt; }
      else { unpaid++; outstanding += amt; }
    });
    return res.json({ totalInvoices: rows.length, paidCount: paid, unpaidCount: unpaid, overdueCount: overdue, totalAmount: total, outstandingAmount: outstanding });
  } catch (e) { console.error('Billing Summary Error:', e); res.status(500).json({ msg: 'Server Error: ' + e.message }); }
});

// Update operational status for a school (ACTIVE/SUSPENDED)
router.put('/:id/status', verifyToken, requireRole('SUPER_ADMIN'), async (req, res) => {
  try {
    const sid = Number(req.params.id);
    const status = String(req.body?.status || '').toUpperCase();
    if (!['ACTIVE','SUSPENDED'].includes(status)) return res.status(400).json({ msg: 'Invalid status' });
    let s = await SchoolSettings.findOne({ where: { schoolId: sid } });
    if (!s) s = await SchoolSettings.create({ schoolId: sid, schoolName: '', academicYearStart: new Date(), academicYearEnd: new Date(), notifications: { email: true, sms: false, push: true } });
    const settings = s.toJSON();
    const next = { ...(settings || {}), operationalStatus: status };
    delete next.id; delete next.createdAt; delete next.updatedAt;
    s.schoolName = next.schoolName || s.schoolName;
    s.schoolAddress = next.schoolAddress || s.schoolAddress;
    s.academicYearStart = next.academicYearStart || s.academicYearStart;
    s.academicYearEnd = next.academicYearEnd || s.academicYearEnd;
    s.notifications = next.notifications || s.notifications;
    s.availableStages = next.availableStages || s.availableStages;
    s.backupConfig = next.backupConfig || s.backupConfig;
    s.operationalStatus = next.operationalStatus;
    await s.save();
    try {
      const { AuditLog } = require('../models');
      await AuditLog.create({ action: 'school.status.update', userId: req.user?.id || null, userEmail: req.user?.email || null, ipAddress: req.ip, userAgent: req.headers['user-agent'], details: JSON.stringify({ schoolId: sid, operationalStatus: status }), timestamp: new Date(), riskLevel: 'medium' });
    } catch {}
    return res.json({ schoolId: sid, status });
  } catch (e) { console.error(e); res.status(500).json({ msg: 'Server Error' }); }
});

router.delete('/:id', verifyToken, requireRole('SUPER_ADMIN'), async (req, res) => {
  try {
    const sid = Number(req.params.id);
    const { User } = require('../models');
    const reason = String((req.query && req.query.reason) || '').slice(0, 500);
    let s = await SchoolSettings.findOne({ where: { schoolId: sid } });
    if (!s) s = await SchoolSettings.create({ schoolId: sid, schoolName: '', academicYearStart: new Date(), academicYearEnd: new Date(), notifications: { email: true, sms: false, push: true } });
    s.operationalStatus = 'DELETED';
    await s.save();
    await User.update({ isActive: false }, { where: { schoolId: sid } });
    try {
      const { AuditLog } = require('../models');
      await AuditLog.create({ action: 'school.delete', userId: req.user?.id || null, userEmail: req.user?.email || null, ipAddress: req.ip, userAgent: req.headers['user-agent'], details: JSON.stringify({ schoolId: sid, reason }), timestamp: new Date(), riskLevel: 'high' });
    } catch {}
    return res.json({ deleted: true });
  } catch (e) { console.error(e); res.status(500).json({ msg: 'Server Error' }); }
});

// @route   GET api/schools/:id/modules
// @desc    Get active modules for a school (Synced with Super Admin SubscriptionModule)
// @access  Private (SchoolAdmin, SuperAdmin)
router.get('/:id/modules', verifyToken, requireRole('SCHOOL_ADMIN', 'SUPER_ADMIN'), requireSameSchoolParam('id'), async (req, res) => {
  return res.status(410).json({ code: 'DEPRECATED', msg: 'School module listing is deprecated' });
});

router.put('/:id/modules', verifyToken, requireRole('SUPER_ADMIN', 'SCHOOL_ADMIN'), requireSameSchoolParam('id'), async (req, res) => {
  return res.status(410).json({ code: 'DEPRECATED', msg: 'School module update is deprecated' });
});

router.post('/:id/modules/activate', verifyToken, requireRole('SUPER_ADMIN'), requireSameSchoolParam('id'), async (req, res) => {
  return res.status(410).json({ code: 'DEPRECATED', msg: 'School module activation is deprecated' });
});

router.get('/:id/stats/student-distribution', verifyToken, requireRole('SCHOOL_ADMIN', 'SUPER_ADMIN'), requireSameSchoolParam('id'), async (req, res) => {
  try {
    const rows = await Student.findAll({
      attributes: ['grade', [sequelize.fn('COUNT', sequelize.col('id')), 'count']],
      where: { schoolId: Number(req.params.id) },
      group: ['grade'],
      order: [[sequelize.literal('count'), 'DESC']]
    });
    const data = rows.map(r => ({ name: r.get('grade'), value: Number(r.get('count')) }));
    res.json(data);
  } catch (err) { console.error(err.message); res.status(500).send('Server Error'); }
});

router.get('/:id/invoices', verifyToken, requireRole('SCHOOL_ADMIN', 'SUPER_ADMIN'), requireSameSchoolParam('id'), async (req, res) => {
  try {
    const invoices = await Invoice.findAll({
      include: { model: Student, attributes: ['name'], where: { schoolId: Number(req.params.id) } },
      order: [['dueDate', 'DESC']]
    });
    const statusMap = { PAID: 'مدفوعة', UNPAID: 'غير مدفوعة', OVERDUE: 'متأخرة' };
    res.json(invoices.map(inv => ({
      id: String(inv.id),
      studentId: inv.studentId,
      studentName: inv.Student.name,
      status: statusMap[inv.status] || inv.status,
      issueDate: inv.createdAt.toISOString().split('T')[0],
      dueDate: inv.dueDate.toISOString().split('T')[0],
      items: [{ description: 'رسوم دراسية', amount: parseFloat(inv.amount) }],
      totalAmount: parseFloat(inv.amount)
    })));
  } catch (err) { console.error(err.message); res.status(500).send('Server Error'); }
});

module.exports = router;
