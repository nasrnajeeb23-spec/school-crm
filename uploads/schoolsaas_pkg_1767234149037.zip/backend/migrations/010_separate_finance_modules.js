module.exports.up = async () => {
  console.log('Migration 010 disabled: activeModules no longer used');
};

module.exports.down = async () => {};
