module.exports = {
  up: async () => {
    console.log('Migration 009 disabled: activeModules no longer used');
  }
};
