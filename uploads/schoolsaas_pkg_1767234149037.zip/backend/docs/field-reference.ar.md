حة 100%# مرجع الحقول والأزرار (Field & Action Reference)

## عام
- schoolId: رقم المدرسة — يجب أن يطابق حساب المستخدم.
- parentId/teacherId: ربط المستخدم بكيان ولي أمر/معلم.

## إعدادات المدرسة
- workingDays: أيام العمل — قائمة نصوص.
- workingHoursStart/End: وقت بداية/نهاية العمل.
- academicYearStart/End: تواريخ العام الدراسي.
- activeModules: وحدات المدرسة — مصفوفة معرفات.

## الرسوم والفواتير
- stage: المرحلة الدراسية.
- tuitionFee/bookFees/uniformFees/activityFees: مبالغ الرسوم.
- paymentPlanType: نوع خطة الدفع.
- paymentPlanDetails: تفاصيل الخطة.
- discounts: قائمة تخفيضات.

## الحضور
- status: حاضر/غائب/متأخر/بعذر.
- date: تاريخ السجل.

## الرواتب
- personType/personId/month: مفاتيح سند الراتب.
- baseAmount/allowancesTotal/deductionsTotal/netAmount: مبالغ أساسية.

## الرسائل
- conversationId: معرف المحادثة.
- attachmentUrl/Type/Name: مرفقات الرسالة.

صحي