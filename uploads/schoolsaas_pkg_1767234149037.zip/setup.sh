#!/bin/bash
echo "Setting up SchoolSaaS Self-Hosted..."

# 1. Install Backend Dependencies
echo "Installing Backend Dependencies..."
cd backend
npm install --production
cd ..



# 3. Create Environment File
if [ ! -f backend/.env ]; then
    echo "Creating .env file..."
    cp backend/.env.example backend/.env 2>/dev/null || echo "Please configure backend/.env manually."
fi

echo "Setup Complete!"
echo "To start the server: cd backend && npm start"
